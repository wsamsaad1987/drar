<footer style="position: fixed; bottom: 0; width: 100%; background: #004d40; color: white; padding: 10px 0; text-align: center;">
  <button id="darkToggle" style="background: none; border: none; color: white; font-size: 18px; margin: 0 10px; cursor: pointer;">
    🌙 الوضع الليلي
  </button>
  <button onclick="sharePage()" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">
    🔗 مشاركة الصفحة
  </button>
</footer>

<script>
  // تفعيل الوضع الليلي
  document.getElementById('darkToggle').addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
  });

  // زر المشاركة
  function sharePage() {
    if (navigator.share) {
      navigator.share({
        title: document.title,
        url: window.location.href
      }).catch(err => console.error('مشكلة في المشاركة:', err));
    } else {
      alert("المتصفح لا يدعم المشاركة.");
    }
  }
</script>

<style>
  .dark-mode {
    background-color: #1e1e1e !important;
    color: #ddd !important;
  }

  .dark-mode a {
    color: #90caf9 !important;
  }

  .dark-mode input,
  .dark-mode textarea,
  .dark-mode select {
    background-color: #333 !important;
    color: #fff !important;
    border: 1px solid #555;
  }
</style>