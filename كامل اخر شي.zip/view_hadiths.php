<?php
// تضمين الاتصال بقاعدة البيانات
include 'db.php';

// استعلام لجلب الأحاديث من قاعدة البيانات
$stmt = $conn->prepare("SELECT * FROM ahadith");
$stmt->execute();
$result = $stmt->get_result();

// عرض الأحاديث في الموقع
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='hadith'>";
        echo "<p><strong>نص الحديث:</strong> " . htmlspecialchars($row['text']) . "</p>";
        echo "<p><strong>الراوي:</strong> " . htmlspecialchars($row['narrator']) . "</p>";
        echo "<p><strong>المصدر:</strong> " . htmlspecialchars($row['source']) . "</p>";
        echo "<p><strong>الحكم:</strong> " . htmlspecialchars($row['hukm']) . "</p>";
        echo "<p><strong>رقم الحديث:</strong> " . htmlspecialchars($row['hadith_number']) . "</p>";
        echo "<p><strong>الجزء:</strong> " . htmlspecialchars($row['volume']) . "</p>";
        echo "<p><strong>الصفحة:</strong> " . htmlspecialchars($row['page']) . "</p>";
        echo "</div><br>";
    }
} else {
    echo "لا توجد أحاديث لعرضها.";
}

$stmt->close();
?>