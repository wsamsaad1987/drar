<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

$ahadith = mysqli_query($conn, "SELECT * FROM ahadith");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إدارة الأحاديث</title>
    <style>
        body { font-family: 'Cairo', sans-serif; direction: rtl; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: right; }
        a.button { padding: 5px 10px; background: #388e3c; color: white; text-decoration: none; border-radius: 5px; }
        a.delete { background: darkred; }
    </style>
</head>
<body>

<h2>إدارة الأحاديث</h2>
<a href="add_hadith.php" class="button">إضافة حديث جديد</a>
<table>
    <tr>
        <th>الحديث</th>
        <th>الراوي</th>
        <th>المصدر</th>
        <th>الإجراءات</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($ahadith)): ?>
        <tr>
            <td><?= htmlspecialchars(substr($row['text'], 0, 100)) ?>...</td>
            <td><?= htmlspecialchars($row['narrator']) ?></td>
            <td><?= htmlspecialchars($row['source']) ?></td>
            <td>
                <a href="edit_hadith.php?id=<?= $row['id'] ?>" class="button">تعديل</a>
                <a href="delete_hadith.php?id=<?= $row['id'] ?>" class="button delete" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>