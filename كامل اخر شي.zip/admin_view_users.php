<?php
include 'db.php';
session_start();

// التحقق من أن المستخدم مشرف - يمكن تعديل هذا حسب النظام الخاص بك
// مثال: if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) { ... }

$result = $conn->query("SELECT id, username, email, created_at FROM users");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>قائمة المستخدمين</title>
  <style>
    body { font-family: 'Cairo', sans-serif; direction: rtl; padding: 20px; background: #f9f9f9; }
    table { width: 100%; border-collapse: collapse; background: #fff; }
    th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
    th { background: #388e3c; color: white; }
    h2 { text-align: center; color: #333; margin-bottom: 20px; }
  </style>
</head>
<body>

<h2>قائمة المستخدمين المسجلين</h2>

<table>
  <tr>
    <th>#</th>
    <th>اسم المستخدم</th>
    <th>البريد الإلكتروني</th>
    <th>تاريخ التسجيل</th>
  </tr>
  <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($row['id']) ?></td>
      <td><?= htmlspecialchars($row['username']) ?></td>
      <td><?= htmlspecialchars($row['email']) ?></td>
      <td><?= htmlspecialchars($row['created_at']) ?></td>
    </tr>
  <?php endwhile; ?>
</table>

</body>
</html>