


<?php

$host = "sql112.infinityfree.com"; // استبدل XXX برقم الاستضافة
$dbname = "if0_38899765_wsam";
$user = "if0_38899765";
$pass = "RLTXqK3nE13h"; // من لوحة InfinityFree

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}
?>

