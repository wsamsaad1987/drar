<?php
session_start();
include 'db.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($id, $hashed_password, $role);
    
    if ($stmt->fetch()) {
        if (password_verify($password, $hashed_password) && $role === 'admin') {
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
            header("Location: dashboard.php");
            exit;
        } else {
            $errors[] = "بيانات غير صحيحة أو ليست لديك صلاحية.";
        }
    } else {
        $errors[] = "المستخدم غير موجود.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>دخول المشرف</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background: #f0f0f0;
            direction: rtl;
            padding: 40px;
        }
        .admin-login-box {
            max-width: 400px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            text-align: right;
        }
        h2 {
            text-align: center;
            color: #004d40;
            margin-bottom: 20px;
        }
        input, button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #00796b;
            color: white;
            border: none;
        }
        button:hover {
            background-color: #004d40;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="admin-login-box">
    <h2><i class="fas fa-user-shield"></i> دخول المشرف</h2>
    
    <?php foreach ($errors as $e): ?>
        <p class="error"><?= htmlspecialchars($e) ?></p>
    <?php endforeach; ?>

    <form method="post">
        <label>اسم المستخدم:</label>
        <input type="text" name="username" placeholder="اسم المستخدم" required>

        <label>كلمة المرور:</label>
        <input type="password" name="password" placeholder="كلمة المرور" required>

        <button type="submit">دخول</button>
    </form>
</div>

</body>
</html>