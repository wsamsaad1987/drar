<?php
include 'db.php';
session_start();

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

$query = "SELECT * FROM ahadith WHERE 1";
$params = [];
$types = "";

if ($search) {
    $query .= " AND (text LIKE ? OR narrator LIKE ? OR hukm LIKE ? OR part LIKE ? OR page LIKE ?)";
    $like = "%$search%";
    $params[] = &$like; $params[] = &$like; $params[] = &$like;
    $params[] = &$like; $params[] = &$like;
    $types .= "sssss";
}

if ($category && $category !== 'الكل') {
    $query .= " AND category = ?";
    $params[] = &$category;
    $types .= "s";
}

$query .= " ORDER BY id DESC";
$stmt = $conn->prepare($query);

if (!empty($params)) {
    array_unshift($params, $types);
    call_user_func_array([$stmt, 'bind_param'], $params);
}

$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>الدرر الشيعية | عرض الأحاديث</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      background: #f4fdf5;
      margin: 0;
      direction: rtl;
    }

    body.dark-mode {
      background-color: #1e1e1e;
      color: #f5f5f5;
    }

    header {
      background-color: #004d40;
      color: white;
      padding: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .login-link {
      color: white;
      text-decoration: none;
      background: #00796b;
      padding: 10px 15px;
      border-radius: 6px;
      font-size: 16px;
    }

    h2 {
      text-align: center;
      margin: 30px 0 10px;
      font-size: 28px;
      color: #004d40;
    }

    form {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }

    input[type="text"], select {
      padding: 12px;
      font-size: 18px;
      border: 1px solid #ccc;
      border-radius: 6px;
      min-width: 200px;
    }

    button {
      padding: 12px 20px;
      background-color: #388e3c;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 18px;
      cursor: pointer;
    }

    .hadith-card {
      background: white;
      margin: 20px auto;
      padding: 25px;
      max-width: 800px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    }

    body.dark-mode .hadith-card {
      background-color: #333;
      color: #fff;
    }

    .hadith-text {
      font-size: 24px;
      margin-bottom: 15px;
      line-height: 1.8;
    }

    .hadith-info {
      font-size: 16px;
      background: #f0f0f0;
      padding: 12px;
      border-radius: 6px;
    }

    body.dark-mode .hadith-info {
      background-color: #444;
      color: #ddd;
    }

    footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      background: #004d40;
      color: white;
      padding: 10px;
      text-align: center;
      font-size: 16px;
    }

    footer button {
      background: transparent;
      border: none;
      color: white;
      font-size: 18px;
      margin: 0 10px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<header>
  <h1>الدرر الشيعية</h1>
  <a class="login-link" href="admin_login.php">دخول المشرف</a>
  
  
  <div>
  <a class="login-link" href="register.php" style="margin-left: 10px;">إنشاء حساب</a>
  <a class="login-link" href="login.php">تسجيل الدخول</a>
</div>
  
  
</header>

<h2>الأحاديث النبوية</h2>

<form method="get">
  <input type="text" name="q" placeholder="ابحث عن حديث أو راوي..." value="<?= htmlspecialchars($search) ?>">
  <select name="category">
    <option value="الكل">كل الأقسام</option>
    <option value="العقيدة" <?= $category == 'العقيدة' ? 'selected' : '' ?>>العقيدة</option>
    <option value="الفقه" <?= $category == 'الفقه' ? 'selected' : '' ?>>الفقه</option>
    <option value="الأخلاق" <?= $category == 'الأخلاق' ? 'selected' : '' ?>>الأخلاق</option>
  </select>
  <button type="submit">بحث</button>
</form>

<?php while($row = $result->fetch_assoc()): ?>
  <div class="hadith-card">
    <div class="hadith-text"><?= htmlspecialchars($row['text']) ?></div>
    <div class="hadith-info">
      الراوي: <?= htmlspecialchars($row['narrator']) ?> |
      المحدث: <?= htmlspecialchars($row['source']) ?> |
      الحكم: <?= htmlspecialchars($row['category']) ?> |
      الجزء: <?=
      htmlspecialchars($row['juz']) ?> |
      الصفحة: <?= htmlspecialchars($row['page']) ?>
      
      <?php if (isset($_SESSION['user_id'])): ?>
        <div style="margin-top: 10px;">
          <a href="edit_hadith.php?id=<?= $row['id'] ?>" style="color: white; background: orange; padding: 6px 12px; border-radius: 4px; text-decoration: none;">تعديل</a>
          <a href="delete_hadith.php?id=<?= $row['id'] ?>" onclick="return confirm('هل تريد حذف هذا الحديث؟');" style="color: white; background: red; padding: 6px 12px; border-radius: 4px; text-decoration: none;">حذف</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php endwhile; ?>

<footer>
  <button id="darkToggle">🌙 الوضع الليلي</button>
  <button onclick="sharePage()">🔗 مشاركة الصفحة</button>
</footer>

<script>
  const body = document.body;
  const darkToggle = document.getElementById('darkToggle');

  // تفعيل الوضع الليلي إذا كان محفوظًا
  if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark-mode');
  }

  darkToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark' : 'light');
  });

  function sharePage() {
    navigator.clipboard.writeText(window.location.href);
    alert("تم نسخ رابط الصفحة!");
  }
</script>

</body>
</html>