<?php
session_start();

// إذا لم يكن المستخدم مسجلاً دخوله، يتم تحويله إلى صفحة الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';

// جلب بيانات المستخدم من قاعدة البيانات
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username, email, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $email, $created_at);
$stmt->fetch();
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الملف الشخصي</title>
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: rtl;
            background: #f4f4f4;
            padding: 40px;
        }

        .profile-box {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
        }

        p {
            margin: 10px 0;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            color: red;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="profile-box">
    <h2>مرحبًا، <?= htmlspecialchars($username) ?>!</h2>
    <p><strong>البريد الإلكتروني:</strong> <?= htmlspecialchars($email) ?></p>
    <p><strong>تاريخ التسجيل:</strong> <?= htmlspecialchars($created_at) ?></p>
    <a href="logout.php">تسجيل الخروج</a>
</div>

</body>
</html>