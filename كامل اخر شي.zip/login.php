<?php


session_start();
include 'db.php';
// يمكن لاحقًا إضافة التحقق من الدخول هنا
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تسجيل الدخول - الدرر الشيعية</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    .login-box {
      max-width: 400px;
      margin: 50px auto;
      background: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: right;
    }
    .login-box h2 {
      text-align: center;
      color: darkgreen;
      margin-bottom: 20px;
    }
    .login-box input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    .login-box button {
      width: 100%;
      padding: 10px;
      background: darkgreen;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }
    .login-box button:hover {
      background: #257a1e;
    }
  </style>
</head>
<body>
  <header class="header-top">
    <h1>الدرر الشيعية</h1>
    <a href="index.php" class="login-icon"><i class="fas fa-home"></i> الرئيسية</a>
  </header>

  <div class="login-box">
    <h2><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</h2>
    <form action="login_process.php" method="post">
      <label>اسم المستخدم:</label>
      <input type="text" name="username" required>

      <label>كلمة المرور:</label>
      <input type="password" name="password" required>

      <button type="submit">دخول</button>
    </form>
  </div>

  <footer>
    <p>جميع الحقوق محفوظة &copy; 2025 - الدرر الشيعية</p>
  </footer>
</body>
</html>