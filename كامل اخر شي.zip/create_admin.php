<?php
include 'db.php';

// بيانات المستخدم الإداري
$username = 'admin';
$password = '123456'; // يمكنك تغييره لكلمة أقوى
$role = 'admin';

// تحقق من عدم وجود المستخدم مسبقاً
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "المستخدم 'admin' موجود بالفعل.";
} else {
    // إنشاء المستخدم
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");