<head>
    <meta charset="UTF-8">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'الدرر الشيعية | الموقع'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        /* الأنماط الافتراضية للموقع */
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #ffffff;
            color: #000000;
            margin: 0;
            direction: rtl;
        }

        /* الأنماط للوضع الليلي */
        body.dark-mode {
            background-color: #121212;
            color: #e0e0e0;
        }

        /* شريط الوضع الليلي في الأسفل */
        .dark-mode-toggle-bar {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #004d40;
            padding: 10px;
            border-radius: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* تنسيق الأيقونة داخل الشريط */
        .moon-toggle {
            font-size: 24px;
            color: #ffffff;
            cursor: pointer;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleIcon = document.getElementById('darkModeToggle');

            toggleIcon.addEventListener('click', () => {
                document.body.classList.toggle('dark-mode');

                if (document.body.classList.contains('dark-mode')) {
                    toggleIcon.classList.remove('fa-moon');
                    toggleIcon.classList.add('fa-sun');
                } else {
                    toggleIcon.classList.remove('fa-sun');
                    toggleIcon.classList.add('fa-moon');
                }
            });
        });
    </script>
</head>


<body>
    <!-- محتوى الصفحة هنا -->
    <h2>مرحبًا بكم في الموقع</h2>
    <p>هنا يمكنك تصفح الأحاديث النبوية وتفاصيلها.</p>

    <!-- شريط الوضع الليلي أسفل الصفحة -->
    <div class="dark-mode-toggle-bar">
        <i id="darkModeToggle" class="fa fa-moon moon-toggle"></i>
    </div>

</body>