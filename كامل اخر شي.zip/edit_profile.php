<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// جلب بيانات المستخدم الحالية
$query = "SELECT * FROM users WHERE id = $user_id LIMIT 1";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// عند إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $imageName = $user['image'];

    // تحديث الاسم
    if (!empty($username)) {
        mysqli_query($conn, "UPDATE users SET username = '$username' WHERE id = $user_id");
    }

    // تحديث كلمة المرور إذا تم تغييرها
    if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($conn, "UPDATE users SET password = '$hashed' WHERE id = $user_id");
    }

    // تحديث الصورة إذا تم رفع صورة جديدة
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $tmp = $_FILES['image']['tmp_name'];
        $name = basename($_FILES['image']['name']);
        $target = "uploads/$name";
        move_uploaded_file($tmp, $target);
        $imageName = $name;
        mysqli_query($conn, "UPDATE users SET image = '$imageName' WHERE id = $user_id");
    }

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تعديل الملف الشخصي</title>
  <link rel="stylesheet" href="style.css">
  <style>
    form {
      max-width: 500px;
      margin: 30px auto;
      background: #f1f1f1;
      padding: 20px;
      border-radius: 8px;
    }
    label {
      display: block;
      margin-top: 10px;
    }
    input[type="text"], input[type="password"], input[type="file"] {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
    }
    button {
      margin-top: 15px;
      padding: 10px 20px;
      background-color: #2e6f1f;
      color: white;
      border: none;
      border-radius: 5px;
    }
    .profile-image {
      text-align: center;
      margin-bottom: 15px;
    }
    .profile-image img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
    }
  </style>
</head>
<body>
  <h2 style="text-align:center;">تعديل الملف الشخصي</h2>
  <form method="POST" enctype="multipart/form-data">
    <div class="profile-image">
      <img src="uploads/<?= htmlspecialchars($user['image']) ?>" alt="صورة المستخدم">
    </div>

    <label>اسم المستخدم</label>
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

    <label>كلمة المرور الجديدة (اتركها فارغة إن لم ترغب بالتغيير)</label>
    <input type="password" name="password">

    <label>صورة جديدة (اختياري)</label>
    <input type="file" name="image" accept="image/*">

    <button type="submit">تحديث البيانات</button>
  </form>
</body>
</html>