<?php
session_start();

// تحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// جلب بيانات المستخدم
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $user_id LIMIT 1";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// جلب الأحاديث من قاعدة البيانات
$hadiths = mysqli_query($conn, "SELECT * FROM ahadith ORDER BY id DESC LIMIT 20");

// جلب جميع المستخدمين للترقية
$users = mysqli_query($conn, "SELECT id, username, role, banned FROM users");
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>لوحة التحكم - الدرر الشيعية</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <style>
    .dashboard-container {
      max-width: 1000px;
      margin: 20px auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: right;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
    }
    th {
      background: #cde3cd;
      color: #2c572c;
    }
    tr:nth-child(even) {
      background: #f9f9f9;
    }
    .upgrade-btn, .demote-btn, .ban-btn {
      background-color: green;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
    }
    .demote-btn {
      background-color: #ff9800;
    }
    .ban-btn {
      background-color: red;
    }
    .upgrade-btn:hover, .demote-btn:hover, .ban-btn:hover {
      background-color: #388e3c;
    }
    .ban-btn:hover {
      background-color: darkred;
    }
    .action-links a {
      margin: 0 5px;
      text-decoration: none;
    }
    .edit-link {
      color: blue;
    }
    .delete-link {
      color: red;
    }
  </style>
</head>
<body>
  <header>
    <h1>الدرر الشيعية - لوحة التحكم</h1>
    <nav>
      <a href="index.php">الرئيسية</a>
      <a href="logout.php">تسجيل الخروج</a>
    </nav>
  </header>

  <div class="dashboard-container">
    <h2>مرحباً، <?= htmlspecialchars($user['username']) ?>!</h2>
    <h3>قائمة الأحاديث</h3>
    <p><a href="add_hadith.php" style="background: darkgreen; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none;">+ إضافة حديث جديد</a></p>

    <h3>إدارة المستخدمين</h3>
    <table>
      <tr>
        <th>اسم المستخدم</th>
        <th>الدور</th>
        <th>الحالة</th>
        <th>الإجراء</th>
      </tr>
      <?php while ($row = mysqli_fetch_assoc($users)): ?>
        <tr>
          <td><?= htmlspecialchars($row['username']) ?></td>
          <td><?= htmlspecialchars($row['role']) ?></td>
          <td><?= $row['banned'] ? 'محظور' : 'مفعل' ?></td>
          <td>
            <?php if ($row['role'] === 'user' && !$row['banned']): ?>
              <a href="upgrade_user.php?user_id=<?= $row['id'] ?>" class="upgrade-btn">ترقية إلى مشرف</a>
            <?php elseif ($row['role'] === 'admin'): ?>
              <a href="demote_user.php?user_id=<?= $row['id'] ?>" class="demote-btn">إزالة الترقية</a>
            <?php endif; ?>
            <?php if ($row['banned']): ?>
              <a href="unban_user.php?user_id=<?= $row['id'] ?>" class="upgrade-btn">إلغاء الحظر</a>
            <?php else: ?>
              <a href="ban_user.php?user_id=<?= $row['id'] ?>" class="ban-btn">حظر المستخدم</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>

    <h3>أحدث الأحاديث</h3>
    <table>
      <tr>
        <th>الحديث</th>
        <th>الراوي</th>
        <th>المصدر</th>
        <th>الحكم</th>
        <th>الإجراء</th>
      </tr>
      <?php while ($row = mysqli_fetch_assoc($hadiths)): ?>
        <tr>
          <td><?= htmlspecialchars(mb_substr($row['text'], 0, 100)) ?>...</td>
          <td><?= htmlspecialchars($row['narrator']) ?></td>
          <td><?= htmlspecialchars($row['source']) ?></td>
          <td><?= htmlspecialchars($row['hukm']) ?></td>
          <td class="action-links">
            <a href="edit_hadith.php?id=<?= $row['id'] ?>" class="edit-link">تعديل</a>
            |
            <a href="delete_hadith.php?id=<?= $row['id'] ?>" class="delete-link" onclick="return confirm('هل تريد حذف هذا الحديث؟');">حذف</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

  <footer>
    <p>جميع الحقوق محفوظة &copy; 2025 - الدرر الشيعية</p>
  </footer>
</body>
</html>