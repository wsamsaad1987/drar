<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // استلام البيانات
    $text = trim($_POST['text']);
    $narrator = trim($_POST['narrator']);
    $source = trim($_POST['source']);
    $hukm = trim($_POST['hukm']);
    $part = trim($_POST['part']);
    $page = trim($_POST['page']);
    $explanation = trim($_POST['explanation']); // الشرح

    // التحقق من صحة المدخلات
    if (empty($text) || empty($narrator) || empty($source) || empty($hukm) || empty($part) || empty($page)) {
        $error = "جميع الحقول مطلوبة.";
    } else {
        // إدخال البيانات في قاعدة البيانات
        $stmt = $conn->prepare("INSERT INTO ahadith (text, narrator, source, hukm, part, page, explanation) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $text, $narrator, $source, $hukm, $part, $page, $explanation);
        $stmt->execute();
        $stmt->close();

        $successMessage = "تم إضافة الحديث بنجاح."; // رسالة النجاح
    }
}

?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>إضافة حديث جديد</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      background: #f4fdf5;
      margin: 0;
      direction: rtl;
    }

    .container {
      max-width: 800px;
      margin: 50px auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #004d40;
    }

    label {
      font-size: 16px;
      color: #333;
    }

    input[type="text"], textarea {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      margin: 10px 0 20px 0;
      border: 1px solid #ccc;
      border-radius: 6px;
      box-sizing: border-box;
    }

    button {
      background-color: #388e3c;
      color: white;
      font-size: 18px;
      border: none;
      padding: 12px 20px;
      border-radius: 6px;
      cursor: pointer;
      width: 100%;
    }

    button:hover {
      background-color: #2c6b2f;
    }

    .error {
      background-color: #f8d7da;
      color: #721c24;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 6px;
      text-align: center;
    }

    .success {
      background-color: #d4edda;
      color: #155724;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 6px;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>إضافة حديث جديد</h2>

  <?php if (isset($error)): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (isset($successMessage)): ?>
    <div class="success"><?= htmlspecialchars($successMessage) ?></div>
  <?php endif; ?>

  <form method="post">
    <label for="text">النص:</label>
    <textarea name="text" id="text" required></textarea>

    <label for="narrator">الراوي:</label>
    <input type="text" id="narrator" name="narrator" required>

    <label for="source">المصدر:</label>
    <input type="text" id="source" name="source" required>

    <label for="hukm">الحكم:</label>
    <input type="text" id="hukm" name="hukm" required>

    <label for="part">الجزء:</label>
    <input type="text" id="part" name="part" required>

    <label for="page">الصفحة:</label>
    <input type="text" id="page" name="page" required>

    <label for="explanation">الشرح:</label>
    <textarea name="explanation" id="explanation"></textarea>

    <button type="submit">إضافة الحديث</button>
  </form>

  <br>
  <div style="text-align: center;">
    <a href="dashboard.php">
      <button style="width: auto; background-color: #ff9800; padding: 10px 20px;">الرجوع إلى القائمة الرئيسية</button>
    </a>
  </div>
</div>

</body>
</html>