<?php
include 'db.php';
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM ahadith WHERE id = $id LIMIT 1");
$hadith = mysqli_fetch_assoc($result);

if (!$hadith) {
    echo "الحديث غير موجود.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>عرض الحديث - الدرر الشيعية</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Tahoma, sans-serif; direction: rtl; background-color: #f9f9f9; padding: 20px; }
    .hadith-box {
      background: #fff;
      padding: 25px;
      border: 1px solid #ccc;
      border-radius: 10px;
      line-height: 2;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    h2 {
      margin-bottom: 20px;
      color: #2e6f1f;
    }
    a.back-link {
      display: inline-block;
      margin-top: 20px;
      color: #2e6f1f;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="hadith-box">
    <h2>الحديث رقم <?= $hadith['id'] ?></h2>
    <p><strong>النص:</strong> <?= nl2br(htmlspecialchars($hadith['text'])) ?></p>
    <p><strong>المحدث:</strong> <?= htmlspecialchars($hadith['mohaddith']) ?></p>
    <p><strong>الحكم:</strong> <?= htmlspecialchars($hadith['hukm']) ?></p>
    <p><strong>الجزء:</strong> <?= htmlspecialchars($hadith['part']) ?></p>

    <a href="index.php" class="back-link">« العودة إلى القائمة</a>
  </div>
</body>
</html>