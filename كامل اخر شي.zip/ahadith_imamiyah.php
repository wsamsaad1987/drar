<?php
session_start();
include 'db.php';

// التحقق إذا كان هناك بحث موجه
$search_query = '';
if (isset($_GET['search'])) {
    $search_query = mysqli_real_escape_string($conn, $_GET['search']);
    $result = mysqli_query($conn, "SELECT * FROM ahadith WHERE text LIKE '%$search_query%' OR narrator LIKE '%$search_query%' OR source LIKE '%$search_query%' OR muhadhith LIKE '%$search_query%' ORDER BY id DESC LIMIT 100");
} else {
    $result = mysqli_query($conn, "SELECT * FROM ahadith ORDER BY id DESC LIMIT 100");
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>موسوعة الأحاديث الإمامية</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body { font-family: 'Tahoma', sans-serif; background: #fff8f0; direction: rtl; margin: 0; padding: 0; }
    header, footer { background: #d35400; color: white; padding: 15px; text-align: center; }
    .container { padding: 20px; max-width: 1000px; margin: auto; }

    .hadith-box {
      background: #fff3e0;
      border: 2px solid #e67e22;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      position: relative;
    }

    .hadith-box::before {
      content: "حديث شريف";
      position: absolute;
      top: -14px;
      right: 15px;
      background: #e67e22;
      color: white;
      padding: 3px 12px;
      border-radius: 8px;
      font-size: 14px;
    }

    .hadith-text {
      font-size: 18px;
      line-height: 1.8;
      margin-bottom: 15px;
      color: #4e342e;
    }

    .meta-line {
      font-size: 15px;
      color: #6e2c00;
      margin-bottom: 5px;
    }

    .meta-line span.label {
      font-weight: bold;
      color: #a84300;
    }

    .search-bar {
      text-align: center;
      margin-bottom: 30px;
    }

    .search-bar input {
      padding: 10px;
      width: 80%;
      font-size: 16px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
  </style>
</head>
<body>

<header>
  <h1><i class="fas fa-scroll"></i> موسوعة الأحاديث الإمامية</h1>
</header>

<div class="container">
  <!-- حقل البحث -->
  <div class="search-bar">
    <form method="get" action="ahadith.php">
      <input type="text" name="search" placeholder="ابحث في الأحاديث..." value="<?= htmlspecialchars($search_query) ?>">
    </form>
  </div>

  <!-- عرض الأحاديث -->
  <?php if (mysqli_num_rows($result) > 0): ?>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
      <div class="hadith-box">
        <div class="hadith-text"><?= htmlspecialchars($row['text']) ?></div>

        <!-- عرض الراوي -->
        <div class="meta-line">
          <span class="label">الراوي:</span> <?= htmlspecialchars(!empty($row['narrator']) ? $row['narrator'] : 'غير معروف') ?>
        </div>

        <!-- عرض المحدث -->
        <div class="meta-line">
          <span class="label">المحدث:</span> <?= htmlspecialchars(!empty($row['muhadith']) ? $row['muhadith'] : 'غير محدد') ?>
        </div>

        <!-- عرض المصدر -->
        <div class="meta-line">
          <span class="label">المصدر:</span> <?= htmlspecialchars(!empty($row['source']) ? $row['source'] : 'غير مذكور') ?>
        </div>

        <!-- عرض الجزء -->
        <div class="meta-line">
          <span class="label">الجزء:</span> <?= htmlspecialchars(!empty($row['part']) ? $row['part'] : 'غير مذكور') ?>
        </div>

        <!-- عرض رقم الصفحة -->
        <div class="meta-line">
          <span class="label">الصفحة:</span> <?= htmlspecialchars(!empty($row['page']) ? $row['page'] : 'غير مذكور') ?>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p>لا توجد نتائج للبحث المحدد.</p>
  <?php endif; ?>
</div>

<footer>
  <p>&copy; 2025 - جميع الحقوق محفوظة - الدرر الشيعية</p>
</footer>

</body>
</html>