<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات

// التعامل مع طلب POST لإضافة حديث جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // استخراج القيم من النموذج
    $text = trim($_POST['text']);
    $narrator = trim($_POST['narrator']);
    $source = trim($_POST['source']);
    $hukm = trim($_POST['hukm']);
    $hadith_number = trim($_POST['hadith_number']);
    $volume = trim($_POST['volume']);
    $page = trim($_POST['page']);
    $explanation = trim($_POST['explanation']); // حقل الشرح الجديد
    
    // التحقق من أن جميع الحقول المطلوبة ليست فارغة
    if (!empty($text) && !empty($volume) && !empty($page)) {
        // إعداد الاستعلام لإدخال الحديث في قاعدة البيانات مع الشرح
        $stmt = $conn->prepare("INSERT INTO ahadith (text, narrator, source, hukm, hadith_number, volume, page, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssisss", $text, $narrator, $source, $hukm, $hadith_number, $volume, $page, $explanation);
        
        if ($stmt->execute()) {
            $success = "تمت إضافة الحديث بنجاح.";
        } else {
            $error = "حدث خطأ أثناء إضافة الحديث. يرجى المحاولة لاحقًا.";
        }

        $stmt->close();
    } else {
        $error = "يرجى ملء جميع الحقول المطلوبة: نص الحديث، الجزء، والصفحة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>إضافة حديث جديد</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      background: #f7fdf9;
      direction: rtl;
      padding: 20px;
    }
    form {
      max-width: 700px;
      margin: 30px auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    label {
      font-weight: bold;
      display: block;
      margin-top: 10px;
    }
    input, textarea {
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    button {
      background: #388e3c;
      color: white;
      border: none;
      padding: 12px 20px;
      font-size: 18px;
      border-radius: 6px;
      cursor: pointer;
    }
    .msg {
      background: #e6ffe6;
      color: darkgreen;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid green;
      border-radius: 5px;
      text-align: center;
    }
    .error {
      background: #ffe6e6;
      color: darkred;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid red;
      border-radius: 5px;
      text-align: center;
    }
    .back-link {
      text-align: center;
      margin-top: 20px;
    }
    .back-link a {
      background: darkgreen;
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <h2 style="text-align:center;">إضافة حديث جديد</h2>

  <?php if (isset($success)): ?>
    <div class="msg"><?= $success ?></div>
  <?php endif; ?>

  <?php if (isset($error)): ?>
    <div class="error"><?= $error ?></div>
  <?php endif; ?>

  <form method="post">
    <label for="text">نص الحديث:</label>
    <textarea name="text" required></textarea>

    <label for="narrator">الراوي:</label>
    <input type="text" name="narrator">

    <label for="source">المصدر:</label>
    <input type="text" name="source">

    <label for="hukm">الحكم (مثلاً: صحيح / ضعيف):</label>
    <input type="text" name="hukm">

    <label for="hadith_number">رقم الحديث:</label>
    <input type="number" name="hadith_number">

    <label for="volume">الجزء:</label>
    <input type="text" name="volume">

    <label for="page">الصفحة:</label>
    <input type="text" name="page">

    <!-- حقل الشرح الجديد -->
    <label for="explanation">شرح الحديث (اختياري):</label>
    <textarea name="explanation"></textarea>

    <button type="submit">إضافة الحديث</button>
  </form>

  <div class="back-link">
    <a href="dashboard.php">الرجوع إلى الصفحة الرئيسية +</a>
  </div>

</body>
</html>