<?php
include 'db.php';
session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password !== $confirm) {
        $errors[] = "كلمتا المرور غير متطابقتين.";
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $role = 'admin'; // يمكنك تغييره إلى 'user' حسب الصلاحية المطلوبة

        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $hash, $role);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "حدث خطأ أثناء التسجيل: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تسجيل حساب جديد</title>
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      direction: rtl;
      padding: 40px;
      background: #f4f4f4;
    }
    form {
      max-width: 400px;
      margin: auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    input {
      display: block;
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      padding: 10px 20px;
      background: #388e3c;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:hover {
      background: #2e7d32;
    }
    .error {
      color: red;
      margin-bottom: 10px;
      text-align: center;
    }
  </style>
</head>
<body>

<h2 style="text-align:center;">تسجيل حساب جديد</h2>

<?php foreach ($errors as $e): ?>
  <div class="error"><?= htmlspecialchars($e) ?></div>
<?php endforeach; ?>

<form method="post">
  <input type="text" name="username" placeholder="اسم المستخدم" required>
  <input type="email" name="email" placeholder="البريد الإلكتروني" required>
  <input type="password" name="password" placeholder="كلمة المرور" required>
  <input type="password" name="confirm" placeholder="تأكيد كلمة المرور" required>
  <button type="submit">تسجيل</button>
</form>

</body>
</html>