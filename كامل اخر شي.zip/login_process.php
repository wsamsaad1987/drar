<?php
session_start();
include 'db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            if ($role === 'admin') {
                $_SESSION['user_id'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
                header("Location: dashboard.php");
                exit;
            } else {
                $errors[] = "ليس لديك صلاحية دخول المشرف.";
            }
        } else {
            $errors[] = "كلمة المرور غير صحيحة.";
        }
    } else {
        $errors[] = "اسم المستخدم غير موجود.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>دخول المشرف</title>
    <style>
        body { font-family: 'Cairo', sans-serif; background: #f0f0f0; direction: rtl; padding: 40px; }
        .box { max-width: 400px; margin: auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        .error { color: red; margin-bottom: 10px; text-align: center; }
        input, button { width: 100%; padding: 10px; margin: 10px 0; border-radius: 6px; border: 1px solid #ccc; }
        button { background: darkgreen; color: white; border: none; }
    </style>
</head>
<body>
<div class="box">
    <h2 style="text-align:center;">تسجيل الدخول للمشرف</h2>
    <?php foreach ($errors as $e): ?>
        <div class="error"><?= htmlspecialchars($e) ?></div>
    <?php endforeach; ?>
    <form method="post">
        <label>اسم المستخدم:</label>
        <input type="text" name="username" required>
        <label>كلمة المرور:</label>
        <input type="password" name="password" required>
        <button type="submit">دخول</button>
    </form>
</div>
</body>
</html>