
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // تحديث دور المستخدم إلى "user"
    $stmt = $conn->prepare("UPDATE users SET role = 'user' WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        header("Location: dashboard.php"); // العودة إلى لوحة التحكم بعد إزالة الترقية
        exit();
    } else {
        echo "حدث خطأ أثناء إزالة الترقية.";
    }
} else {
    echo "المستخدم غير موجود.";
}
?>
