
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // تحديث حالة المستخدم إلى "غير محظور"
    $stmt = $conn->prepare("UPDATE users SET banned = 0 WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        header("Location: dashboard.php"); // العودة إلى لوحة التحكم بعد إلغاء الحظر
        exit();
    } else {
        echo "حدث خطأ أثناء إلغاء حظر المستخدم.";
    }
} else {
    echo "المستخدم غير موجود.";
}
?>
